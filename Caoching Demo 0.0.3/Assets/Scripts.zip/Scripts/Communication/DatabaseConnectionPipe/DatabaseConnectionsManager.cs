﻿/** 
* @file DatabaseConnectionsManager.cs
* @brief Contains the DatabaseConnectionsManager class
* @author Mohammed Haider(Mohammed@heddoko.com)
* @date March 2016
* Copyright Heddoko(TM) 2016, all rights reserved
*/

namespace Assets.Scripts.Communication.DatabaseConnectionPipe
{
    /// <summary>
    /// A manager 
    /// </summary>
    public class DatabaseConnectionsManager
    {
         
    }
}