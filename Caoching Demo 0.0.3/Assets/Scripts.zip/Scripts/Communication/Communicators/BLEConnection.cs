﻿// /**
// * @file BLEConnection.cs
// * @brief Contains the BLEConnection and requirements to run this class and its functions
// * @author Mohammed Haider(mohammed@heddoko.com )
// * @date October 2016
// * Copyright Heddoko(TM) 2016,  all rights reserved
// */
namespace Assets.Scripts.Communication.Communicators
{
    /// <summary>
    /// The BLeConnection to the suit
    /// </summary>
    internal class BLEConnection
    {
    }
}