﻿using System.Collections;

namespace Assets.Scripts.UI.AbstractViews.AbstractPanels.ContextMenuSubControl
{
    public interface IContextMenuElement
    {
        ICollection Data { get; set; } 
    }
}