﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Scripts.UI.Scene_3d.Controller
{
    /// <summary>
    /// Switches between recording 
    /// </summary>
    public class SwitchToDifferentPlayBack
    {
    }
}
