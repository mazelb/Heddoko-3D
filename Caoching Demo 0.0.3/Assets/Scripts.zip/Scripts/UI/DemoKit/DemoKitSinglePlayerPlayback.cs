﻿/**
* @file DemoKitSinglePlayerPlayback.cs
* @brief Contains the 
* @author Mohammed Haider(Mohammed@heddoko.com)
* @date May 2016
* Copyright Heddoko(TM) 2016,  all rights reserved
*/
namespace Assets.Scripts.UI.DemoKit
{
    /// <summary>
    /// Demokit player playback
    /// </summary>
    public class DemoKitSinglePlayerPlayback
    {
         
    }
}