﻿using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.UI.DemoKit.android
{
    public class PlaybackRecordingContainer : MonoBehaviour
    {
        public List<PlaybackRecordingsButton> List;
    }
}