﻿/** 
* @file PanelCamera.cs
* @brief Contains the PanelCamera  class
* @author Mohammed Haider (mohammed@heddoko.com)
* @date February 2016
* Copyright Heddoko(TM) 2016, all rights reserved
*/

using System;
using Assets.Scripts.Body_Data.View;
using Assets.Scripts.UI.AbstractViews.AbstractPanels.AbstractSubControls.cameraSubControls;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Assets.Scripts.UI.AbstractViews.camera
{
    /// <summary>
    /// a panel camera that fits within the confines of a node panel
    /// </summary>
    public class PanelCamera : IEquatable<PanelCamera>
    {
        private Guid mId = new Guid();
        private Camera mPanelRenderingCamera;
        private PanelCameraSettings mSettings;
        private CameraOrbitter mCameraOrbitter;
        private CameraZoom mCameraZoom;
        internal CamViewPlane CamViewPlane = new CamViewPlane();
        internal PhysicsRaycaster PhysicsRaycaster;
        /// <summary>
        /// the camera rendering a panel
        /// </summary>
        public Camera PanelRenderingCamera
        {
            get { return mPanelRenderingCamera; }
            set { mPanelRenderingCamera = value; }
        }



        /// <summary>
        /// getter for panel camera settings
        /// </summary>
        public PanelCameraSettings Settings
        {
            get { return mSettings; }
        }

        public CameraOrbitter Orbitter
        {
            get
            {
                if (mCameraOrbitter == null)
                {
                    mCameraOrbitter = PanelRenderingCamera.gameObject.GetComponent<CameraOrbitter>();
                    if (mCameraOrbitter == null)
                    {
                        mCameraOrbitter = PanelRenderingCamera.gameObject.AddComponent<CameraOrbitter>();
                    }
                }
                return mCameraOrbitter;
            }
            set
            {
                mCameraOrbitter = value;
            }
        }

        public CameraZoom CameraZoom
        {
            get
            {
                if (mCameraZoom == null)
                {
                    mCameraZoom = PanelRenderingCamera.gameObject.GetComponent<CameraZoom>();
                    if (mCameraZoom == null)
                    {
                        mCameraZoom = PanelRenderingCamera.gameObject.AddComponent<CameraZoom>();
                    }
                }
                return mCameraZoom;
            }

        }



        /// <summary>
        /// Sets up the panel camera with the passed in settings
        /// </summary>
        /// <param name="vSettings"></param>
        public void SetupCamera(PanelCameraSettings vSettings = null)
        {
            if (mSettings != vSettings && vSettings != null)
            {
                mSettings = vSettings;
            }
            if (mSettings != null)
            {
                PanelRenderingCamera.clearFlags = CameraClearFlags.Depth;
                PanelRenderingCamera.cullingMask = 1 << mSettings.RenderingLayerMask.value;
                PanelRenderingCamera.orthographic = true;
                PanelRenderingCamera.nearClipPlane = 0.3f;
                PanelRenderingCamera.farClipPlane = 1000f;
                PanelRenderingCamera.orthographicSize = 1.6f;
                PanelRenderingCamera.depth = -1;
                CalculateCamRect();

                PanelRenderingCamera.transform.position = Vector3.back * 10;
                CamViewPlane.CameraPositionChangedEvent -= MoveCameraToPosition;
                CamViewPlane.CameraPositionChangedEvent += MoveCameraToPosition;
                CameraZoom.Camera = PanelRenderingCamera;
                PhysicsRaycaster = PanelRenderingCamera.gameObject.AddComponent<PhysicsRaycaster>();
                PhysicsRaycaster.eventMask = 1 << mSettings.RenderingLayerMask.value;
            }
            else
            {
                throw new NullReferenceException("Illegal: Null setting was passed to a panel camera.");
            }
        }

        /// <summary>
        /// Calculates the camera rect
        /// </summary>
        public void CalculateCamRect()
        {
            PanelRenderingCamera.rect = new Rect(mSettings.BottomLeftViewPortPoint.x,
                  mSettings.BottomLeftViewPortPoint.y,
                  mSettings.TopRightViewPortPoint.x - mSettings.BottomLeftViewPortPoint.x,
                  mSettings.TopRightViewPortPoint.y - mSettings.BottomLeftViewPortPoint.y);
        }

        public bool Equals(PanelCamera other)
        {
            if (other != null)
            {
                return other.mId == mId;
            }
            return false;
        }
        /// <summary>
        /// Updates the current LayerMask with the passed in parameter
        /// </summary>
        /// <param name="vNewLayerMask"></param>
        public void UpdateLayerMask(LayerMask vNewLayerMask)
        {
            Settings.RenderingLayerMask = vNewLayerMask;
            PanelRenderingCamera.cullingMask = Settings.RenderingLayerMask;

        }

        /// <summary>
        /// sets up the cameras position with respect the rendered body
        /// </summary> 
        /// <param name="vBody"></param>
        /// <param name="vDistance"></param>
        public void SetDefaultTarget(RenderedBody vBody, int vDistance)
        {
            CamViewPlane.TargetBody = vBody;
            Transform vTarget = CamViewPlane.TargetBody.Hips;
            Orbitter.Target = vTarget;
            Orbitter.TargetsLayer = 1 << vBody.CurrentLayerMask.value;
            Orbitter.Enable();
            CameraZoom.TargetRenderedBody = vBody;
            CameraZoom.LookAtSubsegmentType = BodyStructureMap.SubSegmentTypes.SubsegmentType_UpperSpine;
            CameraZoom.TargetsLayer = 1 << vBody.CurrentLayerMask.value;
            CameraZoom.Enable();
            CamViewPlane.ReferenceSubSegment = BodyStructureMap.SubSegmentTypes.SubsegmentType_LowerSpine;
            CamViewPlane.ViewPlane = CameraViewPlane.Frontal;
        }



        /// <summary>
        /// Moves the camera to a the specified new position
        /// </summary>
        /// <param name="vNewPos">the new position</param>
        private void MoveCameraToPosition(Vector3 vNewPos)
        {
            PanelRenderingCamera.transform.position = vNewPos;
            PanelRenderingCamera.transform.LookAt(CamViewPlane.TargetBody.GetSubSegmentTransform(CamViewPlane.ReferenceSubSegment));
        }
    }


}
