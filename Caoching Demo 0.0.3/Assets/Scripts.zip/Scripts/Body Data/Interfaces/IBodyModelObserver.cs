﻿ /**
 * @file IBodyModelObserver.cs
 * @brief Contains the 
 * @author Mohammed Haider( 
 * @date 05 2016
 * Copyright Heddoko(TM) 2016,  all rights reserved
 */
namespace Assets.Scripts.Body_Data.Interfaces
{
    public interface IBodyModelObserver
    {
         
    }
}