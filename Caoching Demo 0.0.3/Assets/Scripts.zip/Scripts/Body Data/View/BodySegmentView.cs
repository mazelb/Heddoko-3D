﻿
using UnityEngine;

namespace Assets.Scripts.Body_Data.view
{
    public class BodySegmentView : MonoBehaviour
    {
    }
}
