﻿/**
* @file ProtoFrameDecoder.cs
* @brief Contains the 
* @author Mohammed Haider( 
* @date 06 2016
* Copyright Heddoko(TM) 2016,  all rights reserved
*/
namespace Assets.Scripts.Frames_Pipeline.BodyFrameConversion
{
    public class ProtoFrameDecoder
    {
         
    }
}