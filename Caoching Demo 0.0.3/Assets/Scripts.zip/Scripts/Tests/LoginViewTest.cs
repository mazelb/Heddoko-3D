﻿// /**
// * @file LoginViewTest.cs
// * @brief Contains the 
// * @author Mohammed Haider( 
// * @date 07 2016
// * Copyright Heddoko(TM) 2016,  all rights reserved
// */
namespace Assets.Scripts.Tests
{
    public class LoginViewTest
    {
         
    }
}