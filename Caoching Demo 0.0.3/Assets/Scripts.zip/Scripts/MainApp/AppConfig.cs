public static class AppConfig
{
    ///<summary>
    ///The application version
    ///</summary>
    private static string sVersion = "1.0.25.0";
    public static string Version
    {
        get
        {
            return sVersion;
        }
    }
}