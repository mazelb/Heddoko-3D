﻿namespace Assets.Scripts.Body_Pipeline.Analysis.AnalysisModels.REBA_RULA
{
    public class RulaPoint
    {
         
    }
}